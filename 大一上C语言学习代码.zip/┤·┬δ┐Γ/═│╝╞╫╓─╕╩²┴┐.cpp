#include <stdio.h>
#include <ctype.h> 
 
int main() {
    int count = 0;
    char ch;

    while ((ch = getchar()) != '@') {
        if (isalpha(ch)) {
            count++;
        }
    }
 
    printf("%d\n", count);
 
    return 0;
}
