#include<stdio.h>
int main()
{
	int m,n,s=0,i;
	scanf("%d %d",&m,&n);
	for(i=m;i<=n;i++){
		for(int j=1;j<i;j++){
			if(i%j==0){
				s+=j;
				
				}
			
				
			}
		if(s==i){
			printf("%d ",i);	
		}
		s=0;
	}
	return 0;
}
