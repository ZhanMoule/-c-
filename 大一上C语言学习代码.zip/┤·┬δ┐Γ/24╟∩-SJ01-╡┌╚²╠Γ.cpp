#include<stdio.h>
int main()
{
	int n,s;
	int a;
	scanf("%d %d",&n,&s);
	//s=(a+a+n-1)*n/2
	a=((2*s)/n-n+1)/2.0;
	printf("%d",a);
	if(a != (int)a){
		printf("not exeist");
	return 0;
	}
	while(n>1){
		n-=1;
		printf("%d ",a);
		a+=1;
	}
	printf("%d",a);
	return 0;
	
 } 
