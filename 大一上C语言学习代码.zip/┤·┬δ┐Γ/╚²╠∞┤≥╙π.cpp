#include<stdio.h>

int main(){
	int n,a;
	scanf("%d",&n);
	a=n;
	while (n>5){
		n=n-5;
	}
	if (n==4||n==0){
		printf("Drying in day %d",a);
	} 
	else if(n>=1&&3>=n){
		printf("Fishing in day %d",a);
	}
	return 0;
} 
