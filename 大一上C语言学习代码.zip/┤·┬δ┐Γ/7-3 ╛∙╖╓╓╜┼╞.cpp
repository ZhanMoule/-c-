#include<stdio.h>
int main(){
	int n,sum=0,ava;
	scanf("%d",&n);
	int a[n];
	for (int i=0;i<n;i++){
		scanf("%d",&a[i]);
        sum+=a[i];
	}
    ava=sum/n;
    int temp=0,count=0;
    for (int i=0;i<n;i++){
        if (a[i]<ava){
            temp+=ava-a[i];
            count++;
        }
        else{
            temp-=a[i]-ava;
        }
    }
	printf("%d",count);
	return 0;
}
