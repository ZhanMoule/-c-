#include<stdio.h>
int main(){
	int a[4][4];
	int b[4];
	for (int i=0;i<4;i++){
		for (int j=0;j<4;j++){
			scanf("%d",&a[i][j]);
		}
	}
	
	for (int j=0;j<4;j++){
		int min=a[j][0];
		for (int i=0;i<4;i++){
			
			if (a[i][j]<min){
				min=a[i][j];
			}
		}
		b[j]=min;
	}
	
	for (int i=0;i<4;i++){
		printf("%d ",b[i]);
	}
	return 0;
}
