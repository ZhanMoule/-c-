#include<stdio.h>
int main(){
	int n,i;
	double p;
	
	scanf("%d",&n);
	double a[n];
	int b[n]; 
	for (i=0;i<n;i++){
		scanf("%lf",&p);
		a[i]=p;
	}
	int x,y;
	double sum;
	while (1){
		scanf("%d %d",&x,&y);
		if (x==0){
			break;
		}
		sum+=a[x]*y;
		b[x-1]+=1;
		
	}
	for (i=0;i<n;i++){
		printf("%d",a[i]);
	}
	printf("%.2f",sum);
	return 0;
} 
