#include<stdio.h>

int main(){
	char c[]={"apple"};
	c[0]=c[0]-32;
	printf("%s",c);
	return 0;
}
