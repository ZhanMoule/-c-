#include<stdio.h>

int main()

{

char *p[] = {"BOOL", "OPK", "H", "SP"};

int i;

for (i = 3; i >= 0; i--, i--)

    printf("%c", *p[i]);

printf("\n");

return 0;
}
