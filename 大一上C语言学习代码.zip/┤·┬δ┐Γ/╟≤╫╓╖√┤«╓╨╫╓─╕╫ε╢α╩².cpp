#include<stdio.h>
int main(){
	char a;
	int i=0;
	int d[26]={0};
	while (a[i]!=''){
		i++;
		if (a[i]>='A'&&a[i]<='Z'){
			d[a[i]-65]++;
		}
		else if (a[i]>='a'&&a[i]<='z'){
			d[a[i]-97]++;
		}
	}
	for (int i=0;i<26;i++){
		printf("%d",d[i]);
	}
	return 0;
}
