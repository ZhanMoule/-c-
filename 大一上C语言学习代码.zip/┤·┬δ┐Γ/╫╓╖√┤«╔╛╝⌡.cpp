#include<stdio.h>
#include<string.h>
void sb(char s[],char t){
	int len=strlen(s);
	int l=len;
	for (int i=0;i<len;i++){
		if (s[i]!=t){
			printf("%c",s[i]);
		}
		else{
			l--;
		}
		
	}
	if (l==0){
		printf("NULL");
	}
	printf("\n");
}
int main(){
	int n;
	char s[101],t;
	scanf("%d",&n);
	for (int i=0;i<n;i++){
		scanf("%s %c",&s,&t); 
		sb(s,t);
	}
	
	
	return 0;
}
