#include <stdio.h>
void fun2(int x)
{
  x=30;
  printf("%d\n",x);
}
void fun1( int x)
{
  x=20;
  fun2(x);
  printf("%d\n",x);
}
main()
{
  int x=10;
  fun1(x);
  printf("%d\n",x);
}
