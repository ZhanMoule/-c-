#include <stdio.h>
int main(){
 	int a,b,c,d;
 	scanf("%d %d %d %d",&a,&b,&c,&d);
 	printf(" Season Quantity\n-----------------\n Spring%9d\n Summer%9d\n Autumn%9d\n Winter%9d\n-----------------\n  Total%9d" ,a,b,c,d,a+b+c+d);
	return 0;
}

