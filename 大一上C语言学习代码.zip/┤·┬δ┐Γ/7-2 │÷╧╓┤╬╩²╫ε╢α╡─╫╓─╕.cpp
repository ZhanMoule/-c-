#include<stdio.h>
int main(){
	int a[26];
	char x;
	
	while ((x=getchar())!= 'EOF'){
		scanf("%c",&x);
		if (x>='a'&&x<='z'){
			a[x-97]+=1;
		}
		else if(x>='A'&&x<='Z'){
			a[x-65]+=1;
		}
	}
	int max;
	for (int i=0;i<26;i++){
		if (a[i]>max){
			max=a[i];
		}
	}
	printf("%d",max);
	return 0;
}
