#include <stdio.h>
int main(){
	int i,n,j;
	int a=65;
	scanf("%d",&n);
	for (i=0;i<n;i++){
		j=n;
		while (i<j-1){
			j-=1;
			printf("%c ",a);
			a+=1;				
		}
		printf("%c\n",a);
		a+=1;
		
	}
	return 0;
}
