#include<stdio.h>
int main(){
	int a,b;
	scanf("%d %d",&a,&b);
	switch(a){
		case 0://��� 
			if (b==0){
				printf("biii\n");
				printf("stop\n");
				break;
			}
			else{//�� 
				printf("-\n");
				printf("stop\n");
				break;
			}
		case 1://�̵� 
			if (b==0){
				printf("dudu\n");
				printf("move\n");
				break;
			}
			else{
				printf("-\n");
				printf("move\n");
				break;
			}
		case 2:
			printf("-\n");
			printf("stop\n");
			break;
	}
	return 0;
}
