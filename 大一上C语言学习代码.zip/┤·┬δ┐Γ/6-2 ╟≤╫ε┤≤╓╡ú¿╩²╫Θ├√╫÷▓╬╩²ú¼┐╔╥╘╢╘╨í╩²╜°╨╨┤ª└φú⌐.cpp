#include<stdio.h>
#define N 10
double Find_Maxscore( double a[], int n ){
	int max=0;
	for (int i=0;i<n;i++){
		if (a[i]>max){
			max=a[i];
		}
	}
}
int main()
{

  double a[N];
  
  int i;

  for(i=0;i<N;i++)
        
         scanf("%lf", &a[i]);

  printf("The max score is %.1lf", Find_Maxscore(a,N));

  return 0;

}

