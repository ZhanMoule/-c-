#include<stdio.h>

int main(){
	int n;
	scanf("%d",&n);
	char a[n+1][21];
	for (int i=0;i<n;i++){
		scanf("%s",&a[i]);
		
	}
	for (int i=0;i<n;i++){
		if (a[i][0]>='a'&&a[i][0]<='z'){
			a[i][0]=a[i][0]-32;
		}
		for (int j=1;j<20;j++){
			if (a[i][j]>='A'&&a[i][j]<='Z'){
				a[i][j]=a[i][j]+32;
			}
		}
	}
	for (int i=0;i<n;i++){
		printf("%s\n",&a[i]);
}
	return 0;
}
