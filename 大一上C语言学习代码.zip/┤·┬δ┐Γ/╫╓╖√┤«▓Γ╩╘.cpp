#include<stdio.h>
int main(){
	char ch;
	scanf("%c",&ch);
	for (int i=0;i<10;i++){
		printf("%c",ch[i]);
	}
		
	
	return 0;
}
