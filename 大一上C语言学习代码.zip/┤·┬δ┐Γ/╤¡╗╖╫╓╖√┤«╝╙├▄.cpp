#include<stdio.h>
int main()
{
	int key;
	char a;
	scanf("%c %d",&a,&key);
	if('a'<=a<='z'){
		if(key>=0){
			printf("%c",a+=key);
			return 0;
		} 
		else{
			printf("%c",a=a+key+26);
		}
	}
	return 0;
}
