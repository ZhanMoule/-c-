#include<stdio.h23/10/24 15:04>

int main( )
{   int m=10, n=20;
    printf("%d, %d" ,  m++,  --n);
    return 0;
}    
