#include<stdio.h>
#include<string.h>
int main(){
	char a[100],b[100],c[100];
	scanf("%s",a);
	scanf("%s",b);
	scanf("%s",c);
	char maxc[101],minc[101],no[101];
	strcpy(maxc,a);
	strcpy(minc,b);
	int i=0;
	while (maxc[i]!=b[i]){
	
		if (b[i]>maxc[i]){
			strcpy(maxc,b);
			strcpy(minc,a);
			break;
		}
		i++;
	}
	printf("%s\n",minc);
	printf("%s\n",maxc);
	i=0;
	while (maxc[i]!=c[i]){
		if (c[i]>maxc[i]){
			strcpy(no,maxc);
			strcpy(maxc,c);
			break;
		}	
		i++;
	}
	i=0;
	if (maxc!=c){
		while (minc[i]!=c[i]){
	
			if (c[i]<minc[i]){
				strcpy(no,minc);
				strcpy(minc,c);
				break;
			}	
		i++;
	}
	} 
	printf("%s\n",minc);
	printf("%s\n",no);
	printf("%s",maxc);
	return 0;
} 
