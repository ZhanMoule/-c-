#include<stdio.h>
#include <string.h>
int main(){
	char s[101];
	int a[26]={0};
	scanf("%s",s);
	int len=strlen(s);
	for (int i=0;i<len;i++){
		if (s[i]>='A'&&s[i]<='Z'){
			a[s[i]-'A']++;
		}
		if (s[i]>='a'&&s[i]<='z'){
			a[s[i]-'a']++;
		}
	}
	int max=a[0],p=0;
	for (int j=1;j<26;j++){
		if (a[j]>max){
			max=a[j];
			p=j;
		}
	}
	printf("%c %d",p+97,max); 
	return 0;
}
