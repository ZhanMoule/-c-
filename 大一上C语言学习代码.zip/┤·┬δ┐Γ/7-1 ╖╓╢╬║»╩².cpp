#include<stdio.h>
int fun(int x){
	if (x>0){
		return x;
	}
	else if (x<0){
		return -x;
	}
	else if (x==0){
		return 0;
	}
}
int main(){
	int x,y;
	scanf("%d",&x);
	y=fun(x);
	printf("y = %d",y);
}
