#include<stdio.h>
int main(){
	int a=65;
	char b;
	printf("%c",a);
	b+=a;
	printf("%c",b);
	return 0;
}
