#include<stdio.h>
int main(){
	int n,temp,s,flag=1;
	scanf("%d",&n);
	int a[n];
	for (int i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	scanf("%d",&s);
	for (int i=0;i<n;i++){
		temp=a[i];
		for (int j=i;j<n;j++){
			if (temp+a[j]==s){
				if (temp!=a[j]){
					if (temp>a[j]){
						printf("%d %d",a[j],temp);
				}
					else{
						printf("%d %d",temp,a[j]);
				}
					flag=0;
					break;
				}
				
				
			}
		}
		if (flag==0){
			break;
		}
	}
	if (flag==1){
		printf("Not found");
	}
	return 0;
}
