#include<stdio.h>
int main()
{
    char a;
    int b;
    scanf("%c %d",&a,&b);
    if('a'+b<'a'){
        printf("%c",'a'+b+27);        
    }else{
        printf("%c",'a'+b);}
    return 0;
}
