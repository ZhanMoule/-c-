#include<stdio.h>
int main(){
	int m,n,a,count,i,s;
	scanf("%d %d",&m,&n);
	a=m;
	while (a<n){
		for (i=1;i<a;i++){
			 if (a%i==0){
			 	s+=i;
			 }
			
		}
		if (s==a){
			printf("%d",s);
		}
	}
	
	return 0;
}
