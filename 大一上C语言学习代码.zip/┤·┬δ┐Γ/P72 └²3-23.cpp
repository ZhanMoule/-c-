#include<stdio.h>
int main()
{
	int n,x,y;
	int count;
	printf("Please input nxy");
	scanf("%d %d %d",&n,&x,&y);
	count=n-y*1.0/x;
	printf("%d\n",count);
	return 0;
}
