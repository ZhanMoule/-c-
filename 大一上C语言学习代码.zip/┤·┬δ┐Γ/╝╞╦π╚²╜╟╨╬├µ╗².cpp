#include<stdio.h>
int main()
{
	int height,length;
	printf("Please enter the height and length");
	scanf("%d %d",&height,&length);
	printf("the square is %d\n",(height*length)/2);
	return 0;
 } 
