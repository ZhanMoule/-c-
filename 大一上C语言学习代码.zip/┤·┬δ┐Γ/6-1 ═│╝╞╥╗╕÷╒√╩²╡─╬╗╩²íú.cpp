#include<stdio.h>
int Count_Number (int N){
	int count=0;
	if (N<0){
		N=-N;
	}
	if (N==0){
		count=1;
	}
	while (N>0){
	 	count++;
	 	N=N/10;
	}
	
	return count;
}
int main()
{

  int N, D=0;

  scanf("%d",&N);
 
  D=Count_Number(N);
  printf("%d", D);
  return 0;
}
