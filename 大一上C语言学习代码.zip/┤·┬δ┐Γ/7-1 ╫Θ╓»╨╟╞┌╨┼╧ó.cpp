#include<stdio.h>
#include<string.h> 
int main(){
	int n;
	scanf("%d",&n);
	char a[10],*b[7]={"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"}; ;
	for (int i=0;i<n;i++){
		scanf("%s",&a);
		int flag=0;
		for (int j=0;j<7;j++){
			if (!strcmp(a,b[j])){
				printf("%d\n",j+1);
				flag=1;
				break;
			}
		}
		if (flag==0){
			printf("-1\n");
		}
	}
	
	return 0;
}
