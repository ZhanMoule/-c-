#include<stdio.h>
int main()
{
	float x,y=0.3;
	y=y*11;
	x=3+0.3;
	if (x==y)
	    printf("ok,x==y\n");
	else
	    printf("no,x!=y\n");
	return 0;
}
